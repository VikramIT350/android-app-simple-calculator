import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: CalculatorHome(),
    );
  }
}

class CalculatorHome extends StatefulWidget {
  @override
  _CalculatorHomeState createState() => _CalculatorHomeState();
}

class _CalculatorHomeState extends State<CalculatorHome> {
  String _output = "0";
  String _expression = "";
  double _num1 = 0.0;
  double _num2 = 0.0;
  String _operator = "";

  void buttonPressed(String buttonText) {
    if (buttonText == "CLEAR") {
      setState(() {
        _output = "0";
        _expression = "";
        _num1 = 0.0;
        _num2 = 0.0;
        _operator = "";
      });
    } else if (buttonText == "+" || buttonText == "-" || buttonText == "*" || buttonText == "/" || buttonText == "%") {
      _num1 = double.parse(_expression);
      _operator = buttonText;
      setState(() {
        _expression += buttonText;
      });
    } else if (buttonText == ".") {
      if (!_expression.contains(".")) {
        setState(() {
          _expression += buttonText;
        });
      }
    } else if (buttonText == "=") {
      _num2 = double.parse(_expression.split(_operator)[1]);

      String result;
      if (_operator == "+") {
        result = (_num1 + _num2).toString();
      } else if (_operator == "-") {
        result = (_num1 - _num2).toString();
      } else if (_operator == "*") {
        result = (_num1 * _num2).toString();
      } else if (_operator == "/") {
        result = (_num1 / _num2).toString();
      } else if (_operator == "%") {
        result = (_num1 % _num2).toString();
      } else {
        result = "0";
      }

      setState(() {
        _output = double.parse(result).toStringAsFixed(2).replaceAll(RegExp(r"([.]*0+)(?!.*\d)"), "");
        _expression = _output;
      });

      _num1 = 0.0;
      _num2 = 0.0;
      _operator = "";
    } else {
      setState(() {
        _expression += buttonText;
      });
    }
  }

  Widget buildButton(String buttonText) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.all(24.0),
          ),
          child: Text(
            buttonText,
            style: TextStyle(
              fontSize: 20.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          onPressed: () => buttonPressed(buttonText),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Simple Calculator"),
      ),
      body: Column(
        children: <Widget>[
          Container(
            alignment: Alignment.centerRight,
            padding: EdgeInsets.symmetric(
              vertical: 24.0,
              horizontal: 12.0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  _expression,
                  style: TextStyle(
                    fontSize: 24.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  _output,
                  style: TextStyle(
                    fontSize: 48.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Divider(),
          ),
          Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  buildButton("7"),
                  buildButton("8"),
                  buildButton("9"),
                  buildButton("/"),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("4"),
                  buildButton("5"),
                  buildButton("6"),
                  buildButton("*"),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("1"),
                  buildButton("2"),
                  buildButton("3"),
                  buildButton("-"),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("."),
                  buildButton("0"),
                  buildButton("00"),
                  buildButton("+"),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("CLEAR"),
                  buildButton("="),
                  buildButton("%"),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
